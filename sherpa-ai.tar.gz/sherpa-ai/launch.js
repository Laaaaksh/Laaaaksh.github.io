#!/usr/bin/env node

/**
 * Launch Script for Sherpa AI
 * Simple launcher that provides clear feedback about server status
 */

const { spawn } = require('child_process');
const axios = require('axios');

const PORT = process.env.PORT || 3000;

console.log(`
🚂 ================================
   Launching Sherpa AI Server
🚂 ================================
`);

// Start the server
const server = spawn('node', ['server/index.js'], {
    stdio: 'inherit',
    cwd: __dirname
});

// Handle server events
server.on('spawn', () => {
    console.log('✅ Server process started');
    
    // Wait a bit then test the connection
    setTimeout(async () => {
        try {
            const response = await axios.get(`http://localhost:${PORT}/api/health`);
            console.log(`
🎉 ================================
   Sherpa AI is Ready!
🎉 ================================

🌐 Open your browser and go to:
   👉 http://localhost:${PORT}

📡 API Health Check:
   ✅ ${response.data.status} - ${response.data.service}

💬 Try these commands:
   • "Hello Sherpa!"
   • "Find trains from Delhi to Mumbai"  
   • "Who are you?"
   • "Show trains from Bangalore to Chennai"

================================
`);
        } catch (error) {
            console.log(`
❌ Server health check failed: ${error.message}
🔄 The server might still be starting up...
⏳ Please wait a moment and try http://localhost:${PORT}
`);
        }
    }, 3000);
});

server.on('error', (error) => {
    console.error('❌ Failed to start server:', error.message);
    process.exit(1);
});

server.on('close', (code) => {
    console.log(`\n🛑 Server stopped with code ${code}`);
    process.exit(code);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down Sherpa AI...');
    server.kill('SIGINT');
});

process.on('SIGTERM', () => {
    console.log('\n🛑 Shutting down Sherpa AI...');
    server.kill('SIGTERM');
});