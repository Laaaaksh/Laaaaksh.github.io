#!/usr/bin/env node

/**
 * Simple API Test Script for Sherpa AI
 * Tests both train search and general chat functionality
 */

const axios = require('axios');

const API_BASE = 'http://localhost:3000/api';

async function testAPI() {
    console.log('🚂 Testing Sherpa AI API...\n');

    try {
        // Test 1: Health Check
        console.log('1️⃣ Testing Health Check...');
        const healthResponse = await axios.get(`${API_BASE}/health`);
        console.log('✅ Health Check:', healthResponse.data.status);
        console.log();

        // Test 2: Train Search Query
        console.log('2️⃣ Testing Train Search...');
        const trainSearchResponse = await axios.post(`${API_BASE}/search-trains`, {
            query: 'Find trains from Delhi to Mumbai'
        });
        
        if (trainSearchResponse.data.trains) {
            console.log(`✅ Train Search: Found ${trainSearchResponse.data.trains.length} trains`);
            console.log(`   Route: ${trainSearchResponse.data.searchParams?.from} → ${trainSearchResponse.data.searchParams?.to}`);
        } else {
            console.log('✅ Train Search Response:', trainSearchResponse.data.message.substring(0, 80) + '...');
        }
        console.log();

        // Test 3: General Chat Query
        console.log('3️⃣ Testing General Chat...');
        const chatResponse = await axios.post(`${API_BASE}/search-trains`, {
            query: 'Hello, how are you?'
        });
        console.log('✅ General Chat Response:', chatResponse.data.message.substring(0, 80) + '...');
        console.log();

        // Test 4: Station Suggestions
        console.log('4️⃣ Testing Station Suggestions...');
        const suggestionsResponse = await axios.get(`${API_BASE}/stations/suggest/del`);
        console.log('✅ Station Suggestions:', suggestionsResponse.data.suggestions.slice(0, 3).join(', '));
        console.log();

        // Test 5: Popular Routes
        console.log('5️⃣ Testing Popular Routes...');
        const routesResponse = await axios.get(`${API_BASE}/popular-routes`);
        console.log('✅ Popular Routes:', routesResponse.data.routes.length, 'routes found');
        console.log();

        console.log('🎉 All tests passed! Sherpa AI is working correctly.');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
        
        if (error.code === 'ECONNREFUSED') {
            console.log('\n💡 Server might not be running. Start it with: npm start');
        } else if (error.response) {
            console.log('Response status:', error.response.status);
            console.log('Response data:', error.response.data);
        }
    }
}

// Enhanced test function with more detailed checks
async function runDetailedTests() {
    console.log('🔍 Running Detailed API Tests...\n');

    const testCases = [
        {
            name: 'Train Search - Delhi to Mumbai',
            query: 'Find trains from Delhi to Mumbai',
            expectedType: 'train'
        },
        {
            name: 'Train Search - Bangalore to Chennai',
            query: 'Show trains from Bangalore to Chennai',
            expectedType: 'train'
        },
        {
            name: 'General Chat - Greeting',
            query: 'Hello Sherpa!',
            expectedType: 'chat'
        },
        {
            name: 'General Chat - About',
            query: 'Who are you?',
            expectedType: 'chat'
        },
        {
            name: 'General Chat - Travel Tips',
            query: 'Any travel tips?',
            expectedType: 'chat'
        },
        {
            name: 'Edge Case - Unclear Query',
            query: 'trains',
            expectedType: 'unclear'
        }
    ];

    for (const testCase of testCases) {
        try {
            console.log(`🧪 Testing: ${testCase.name}`);
            const response = await axios.post(`${API_BASE}/search-trains`, {
                query: testCase.query,
                sessionId: 'test-session'
            });

            const { data } = response;
            const responseType = data.isTrainSearch ? 'train' : 
                                data.isGeneral ? 'chat' : 'unclear';

            console.log(`   Query: "${testCase.query}"`);
            console.log(`   Type: ${responseType}`);
            console.log(`   Response: ${data.message.substring(0, 60)}...`);
            
            if (data.trains) {
                console.log(`   Trains Found: ${data.trains.length}`);
            }
            
            console.log('   ✅ Success\n');
            
        } catch (error) {
            console.log(`   ❌ Error: ${error.message}\n`);
        }
    }
}

// Run tests
if (require.main === module) {
    console.log('🚂 Starting Sherpa AI API Tests...\n');
    
    // Give server time to start if just launched
    setTimeout(async () => {
        await testAPI();
        console.log('\n' + '='.repeat(50));
        await runDetailedTests();
        console.log('🏁 Testing complete!');
    }, 2000);
}

module.exports = { testAPI, runDetailedTests };