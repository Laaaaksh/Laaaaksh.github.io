const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const bodyParser = require('body-parser');
const path = require('path');

const TrainSearchService = require('./services/trainSearchService');
const QueryProcessor = require('./services/queryProcessor');
const ChatService = require('./services/chatService');

// Import Groq for LLM functionality
const Groq = require('groq-sdk');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet({
    contentSecurityPolicy: false, // Disable for development
}));
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files
app.use(express.static(path.join(__dirname, '..')));

// Services
const trainSearchService = new TrainSearchService();
const queryProcessor = new QueryProcessor();
const chatService = new ChatService();

// LLM Configuration
const groq = process.env.GROQ_API_KEY ? new Groq({
    apiKey: process.env.GROQ_API_KEY
}) : null;

const systemPrompt = `You are Sherpa AI, an intelligent and friendly travel assistant. You have a warm, helpful personality and can assist with:

1. TRAIN BOOKING: Help users find trains between Indian stations, provide travel tips, and railway information.

2. GENERAL CONVERSATION: Engage in natural, friendly conversation while maintaining your identity as a travel assistant.

3. FUTURE TRAVEL SERVICES: You're part of the trippechalo platform and will soon help with flights, hotels, and travel experiences too!

Your personality traits:
- Warm, friendly, and approachable
- Knowledgeable about Indian travel
- Helpful and solution-oriented
- Conversational and engaging
- Professional but not formal

Always maintain context of being a travel assistant. For train searches, guide users to use proper station names. Keep responses concise but helpful, typically 1-3 paragraphs. Use emojis sparingly but appropriately.`;

// Store conversation history per session
const conversationHistory = new Map();

// LLM Helper Function
async function generateLLMResponse(message, sessionId) {
    try {
        // Get or create conversation history for this session
        if (!conversationHistory.has(sessionId)) {
            conversationHistory.set(sessionId, []);
        }
        
        const history = conversationHistory.get(sessionId);
        
        // Prepare messages for LLM
        const messages = [
            { role: 'system', content: systemPrompt }
        ];
        
        // Add recent conversation history (last 6 messages)
        const recentHistory = history.slice(-6);
        recentHistory.forEach(msg => {
            messages.push({
                role: msg.role,
                content: msg.content
            });
        });
        
        // Add current message
        messages.push({ role: 'user', content: message });
        
        // Call Groq LLM API
        const chatCompletion = await groq.chat.completions.create({
            messages: messages,
            model: 'llama-3.1-8b-instant', // Fast and free model
            temperature: 0.7,
            max_tokens: 500,
            top_p: 0.9
        });
        
        const response = chatCompletion.choices[0]?.message?.content?.trim();
        
        if (!response) {
            throw new Error('Empty response from LLM');
        }
        
        // Store conversation in history
        history.push({ role: 'user', content: message, timestamp: new Date() });
        history.push({ role: 'assistant', content: response, timestamp: new Date() });
        
        // Keep only last 20 messages for memory management
        if (history.length > 20) {
            history.splice(0, history.length - 20);
        }
        
        return {
            message: response,
            usedLLM: true,
            timestamp: new Date().toISOString(),
            sessionId: sessionId
        };
        
    } catch (error) {
        console.error('Error generating LLM response:', error);
        throw error;
    }
}

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        service: 'Sherpa AI Travel Assistant API',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        llmStatus: {
            isConfigured: !!groq,
            apiKeyPresent: !!process.env.GROQ_API_KEY,
            model: groq ? 'llama-3.1-8b-instant' : 'not configured'
        }
    });
});

// LLM status endpoint  
app.get('/api/llm-status', (req, res) => {
    res.json({
        isConfigured: !!groq,
        apiKeyPresent: !!process.env.GROQ_API_KEY,
        model: groq ? 'llama-3.1-8b-instant' : 'not configured',
        provider: 'Groq',
        conversationSessions: conversationHistory.size
    });
});

// Main chat endpoint - handles both train search and general conversation
app.post('/api/search-trains', async (req, res) => {
    try {
        const { query, sessionId = 'default' } = req.body;

        if (!query || query.trim().length === 0) {
            return res.status(400).json({
                error: 'Please provide a search query'
            });
        }

        console.log(`[${new Date().toISOString()}] Query: "${query}"`);

        // Determine if this is a train search query or general chat
        const isTrainQuery = chatService.isTrainQuery(query);

        if (isTrainQuery) {
            // Handle train search
            console.log('Processing as train search query...');
            
            // Process the natural language query
            const searchParams = queryProcessor.parseQuery(query);
            
            if (!searchParams.from || !searchParams.to) {
                return res.json({
                    message: `🤔 I couldn't understand the stations in your query. Please try something like:
                    
• "Find trains from Delhi to Mumbai"
• "Show trains from Bangalore to Chennai"  
• "Mumbai to Pune trains"

Make sure to include both source and destination stations.`,
                    suggestion: 'Try specifying both departure and arrival stations clearly.',
                    isTrainSearch: false
                });
            }

            // Search for trains
            const trains = await trainSearchService.searchTrains(searchParams);

            if (trains.length === 0) {
                return res.json({
                    message: `😔 Sorry, I couldn't find any trains from ${searchParams.from} to ${searchParams.to}. 

This might be because:
• The station names might be misspelled
• There might be no direct trains on this route
• The route might require connecting trains

Try searching for trains to nearby major stations or check the spelling of station names.`,
                    trains: [],
                    isTrainSearch: true
                });
            }

            // Return successful response
            return res.json({
                trains: trains,
                searchParams: searchParams,
                message: `✅ Found ${trains.length} trains from ${searchParams.from} to ${searchParams.to}`,
                timestamp: new Date().toISOString(),
                isTrainSearch: true
            });

        } else {
            // Handle general chat with LLM
            console.log('Processing as general chat...');
            
            let chatResponse;
            
            if (groq) {
                // Use LLM for intelligent conversation
                try {
                    chatResponse = await generateLLMResponse(query, sessionId);
                } catch (error) {
                    console.error('LLM API error:', error.message);
                    // Fallback to basic chat service
                    const fallbackResponse = await chatService.processGeneralChat(query, sessionId);
                    chatResponse = {
                        message: `I'm having some technical difficulties with my AI systems. Let me help you with a basic response:\n\n${fallbackResponse.message}`,
                        usedLLM: false,
                        timestamp: new Date().toISOString(),
                        sessionId: sessionId
                    };
                }
            } else {
                // Fallback to basic chat service when no LLM configured
                const fallbackResponse = await chatService.processGeneralChat(query, sessionId);
                chatResponse = {
                    message: fallbackResponse.message + "\n\n💡 *Note: For enhanced AI conversations, configure your GROQ_API_KEY in the environment.*",
                    usedLLM: false,
                    timestamp: fallbackResponse.timestamp,
                    sessionId: sessionId
                };
            }
            
            return res.json({
                message: chatResponse.message,
                isGeneral: true,
                isTrainSearch: false,
                timestamp: chatResponse.timestamp,
                sessionId: chatResponse.sessionId,
                usedLLM: chatResponse.usedLLM
            });
        }

    } catch (error) {
        console.error('Error in processing query:', error);
        res.status(500).json({
            error: 'Internal server error. Please try again later.',
            message: '🚫 Something went wrong while processing your request. Our team has been notified.'
        });
    }
});

// Station suggestions endpoint
app.get('/api/stations/suggest/:query', (req, res) => {
    const query = req.params.query.toLowerCase();
    const stations = trainSearchService.getStationSuggestions(query);
    
    res.json({
        suggestions: stations.slice(0, 10),
        query: query
    });
});

// Popular routes endpoint
app.get('/api/popular-routes', (req, res) => {
    const popularRoutes = [
        { from: 'New Delhi', to: 'Mumbai Central', count: 1250 },
        { from: 'Bangalore', to: 'Chennai Central', count: 980 },
        { from: 'Delhi', to: 'Kolkata', count: 875 },
        { from: 'Mumbai', to: 'Pune', count: 720 },
        { from: 'Hyderabad', to: 'Bangalore', count: 650 },
        { from: 'Chennai', to: 'Bangalore', count: 580 },
        { from: 'Delhi', to: 'Jaipur', count: 540 },
        { from: 'Mumbai', to: 'Goa', count: 420 }
    ];

    res.json({
        routes: popularRoutes,
        message: 'Most popular train routes'
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({
        error: 'Internal server error',
        message: 'Something went wrong. Please try again later.'
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        error: 'Endpoint not found',
        message: 'The requested endpoint does not exist.'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`
🚂 ================================
   Sherpa AI Server Running!
🚂 ================================

🌐 Local:      http://localhost:${PORT}
📡 API Health: http://localhost:${PORT}/api/health
🔍 Search API: http://localhost:${PORT}/api/search-trains

🚀 Ready to help with train bookings!
================================
`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down Sherpa AI server...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n🛑 Shutting down Sherpa AI server...');
    process.exit(0);
});

module.exports = app;