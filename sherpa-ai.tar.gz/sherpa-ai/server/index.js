const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const bodyParser = require('body-parser');
const path = require('path');

const TrainSearchService = require('./services/trainSearchService');
const QueryProcessor = require('./services/queryProcessor');
const ChatService = require('./services/chatService');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet({
    contentSecurityPolicy: false, // Disable for development
}));
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files
app.use(express.static(path.join(__dirname, '..')));

// Services
const trainSearchService = new TrainSearchService();
const queryProcessor = new QueryProcessor();
const chatService = new ChatService();

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        service: 'Sherpa AI Train Search API',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// Main chat endpoint - handles both train search and general conversation
app.post('/api/search-trains', async (req, res) => {
    try {
        const { query, sessionId = 'default' } = req.body;

        if (!query || query.trim().length === 0) {
            return res.status(400).json({
                error: 'Please provide a search query'
            });
        }

        console.log(`[${new Date().toISOString()}] Query: "${query}"`);

        // Determine if this is a train search query or general chat
        const isTrainQuery = chatService.isTrainQuery(query);

        if (isTrainQuery) {
            // Handle train search
            console.log('Processing as train search query...');
            
            // Process the natural language query
            const searchParams = queryProcessor.parseQuery(query);
            
            if (!searchParams.from || !searchParams.to) {
                return res.json({
                    message: `🤔 I couldn't understand the stations in your query. Please try something like:
                    
• "Find trains from Delhi to Mumbai"
• "Show trains from Bangalore to Chennai"  
• "Mumbai to Pune trains"

Make sure to include both source and destination stations.`,
                    suggestion: 'Try specifying both departure and arrival stations clearly.',
                    isTrainSearch: false
                });
            }

            // Search for trains
            const trains = await trainSearchService.searchTrains(searchParams);

            if (trains.length === 0) {
                return res.json({
                    message: `😔 Sorry, I couldn't find any trains from ${searchParams.from} to ${searchParams.to}. 

This might be because:
• The station names might be misspelled
• There might be no direct trains on this route
• The route might require connecting trains

Try searching for trains to nearby major stations or check the spelling of station names.`,
                    trains: [],
                    isTrainSearch: true
                });
            }

            // Return successful response
            return res.json({
                trains: trains,
                searchParams: searchParams,
                message: `✅ Found ${trains.length} trains from ${searchParams.from} to ${searchParams.to}`,
                timestamp: new Date().toISOString(),
                isTrainSearch: true
            });

        } else {
            // Handle general chat
            console.log('Processing as general chat...');
            
            const chatResponse = await chatService.processGeneralChat(query, sessionId);
            
            return res.json({
                message: chatResponse.message,
                isGeneral: true,
                isTrainSearch: false,
                timestamp: chatResponse.timestamp,
                sessionId: chatResponse.sessionId
            });
        }

    } catch (error) {
        console.error('Error in processing query:', error);
        res.status(500).json({
            error: 'Internal server error. Please try again later.',
            message: '🚫 Something went wrong while processing your request. Our team has been notified.'
        });
    }
});

// Station suggestions endpoint
app.get('/api/stations/suggest/:query', (req, res) => {
    const query = req.params.query.toLowerCase();
    const stations = trainSearchService.getStationSuggestions(query);
    
    res.json({
        suggestions: stations.slice(0, 10),
        query: query
    });
});

// Popular routes endpoint
app.get('/api/popular-routes', (req, res) => {
    const popularRoutes = [
        { from: 'New Delhi', to: 'Mumbai Central', count: 1250 },
        { from: 'Bangalore', to: 'Chennai Central', count: 980 },
        { from: 'Delhi', to: 'Kolkata', count: 875 },
        { from: 'Mumbai', to: 'Pune', count: 720 },
        { from: 'Hyderabad', to: 'Bangalore', count: 650 },
        { from: 'Chennai', to: 'Bangalore', count: 580 },
        { from: 'Delhi', to: 'Jaipur', count: 540 },
        { from: 'Mumbai', to: 'Goa', count: 420 }
    ];

    res.json({
        routes: popularRoutes,
        message: 'Most popular train routes'
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({
        error: 'Internal server error',
        message: 'Something went wrong. Please try again later.'
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        error: 'Endpoint not found',
        message: 'The requested endpoint does not exist.'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`
🚂 ================================
   Sherpa AI Server Running!
🚂 ================================

🌐 Local:      http://localhost:${PORT}
📡 API Health: http://localhost:${PORT}/api/health
🔍 Search API: http://localhost:${PORT}/api/search-trains

🚀 Ready to help with train bookings!
================================
`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down Sherpa AI server...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n🛑 Shutting down Sherpa AI server...');
    process.exit(0);
});

module.exports = app;