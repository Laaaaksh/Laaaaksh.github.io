class TrainSearchService {
    constructor() {
        this.stations = this.initializeStations();
        this.trains = this.initializeTrains();
    }

    initializeStations() {
        return [
            // Major cities
            'New Delhi', 'Mumbai Central', 'Chennai Central', 'Kolkata', 'Bangalore',
            'Hyderabad', 'Pune', 'Ahmedabad', 'Jaipur', 'Lucknow', 'Kanpur',
            'Nagpur', 'Indore', 'Bhopal', 'Chandigarh', 'Coimbatore', 'Madurai',
            'Kochi', 'Thiruvananthapuram', 'Guwahati', 'Bhubaneswar', 'Patna',
            'Ranchi', 'Jammu', 'Amritsar', 'Dehradun', 'Haridwar', 'Varanasi',
            'Allahabad', 'Gwalior', 'Jabalpur', 'Raipur', 'Bilaspur', 'Visakhapatnam',
            'Vijayawada', 'Guntur', 'Tirupati', 'Mysore', 'Mangalore', 'Hubli',
            'Belgaum', 'Goa', 'Nashik', 'Aurangabad', 'Solapur', 'Kolhapur',
            'Rajkot', 'Surat', 'Vadodara', 'Jodhpur', 'Udaipur', 'Ajmer',
            'Bikaner', 'Kota', 'Agra', 'Mathura', 'Meerut', 'Bareilly',
            'Moradabad', 'Gorakhpur', 'Faizabad', 'Sitapur', 'Hardoi',
            
            // Railway station codes for better matching
            'NDLS', 'CSTM', 'MAS', 'HWH', 'SBC', 'SC', 'PUNE', 'ADI', 'JP',
            'LKO', 'CNB', 'NGP', 'INDB', 'BPL', 'CDG', 'CBE', 'MDU', 'ERS',
            'TVC', 'GHY', 'BBS', 'PNBE', 'RNC', 'JAT', 'ASR', 'DDN', 'HW',
            'BSB', 'ALD', 'GWL', 'JBP', 'R', 'BSP', 'VSKP', 'BZA', 'GNT',
            'TPTY', 'MYS', 'MAQ', 'UBL', 'BGM', 'MAO', 'NK', 'AWB', 'SUR',
            'KOP', 'RJT', 'ST', 'BRC', 'JU', 'UDZ', 'AII', 'BKN', 'KOTA',
            'AGC', 'MTJ', 'MTC', 'BE', 'MDL', 'GKP', 'FD', 'STP', 'HRI'
        ];
    }

    initializeTrains() {
        return [
            // Delhi to Mumbai trains
            {
                number: '12951',
                name: 'Mumbai Rajdhani Express',
                from: 'New Delhi',
                to: 'Mumbai Central',
                departureTime: '16:55',
                arrivalTime: '08:35',
                duration: '15h 40m',
                classes: ['1A', '2A', '3A'],
                availability: 'Available',
                type: 'Superfast',
                days: ['Daily']
            },
            {
                number: '12953',
                name: 'August Kranti Rajdhani Express',
                from: 'New Delhi',
                to: 'Mumbai Central',
                departureTime: '17:20',
                arrivalTime: '09:55',
                duration: '16h 35m',
                classes: ['1A', '2A', '3A'],
                availability: 'Waiting List',
                type: 'Superfast',
                days: ['Daily']
            },
            {
                number: '12009',
                name: 'Shatabdi Express',
                from: 'New Delhi',
                to: 'Mumbai Central',
                departureTime: '06:00',
                arrivalTime: '21:30',
                duration: '15h 30m',
                classes: ['CC', 'EC'],
                availability: 'Available',
                type: 'Express',
                days: ['Daily except Sunday']
            },

            // Mumbai to Delhi trains
            {
                number: '12952',
                name: 'Mumbai Rajdhani Express',
                from: 'Mumbai Central',
                to: 'New Delhi',
                departureTime: '17:00',
                arrivalTime: '09:15',
                duration: '16h 15m',
                classes: ['1A', '2A', '3A'],
                availability: 'Available',
                type: 'Superfast',
                days: ['Daily']
            },
            {
                number: '12954',
                name: 'August Kranti Rajdhani Express',
                from: 'Mumbai Central',
                to: 'New Delhi',
                departureTime: '17:55',
                arrivalTime: '10:00',
                duration: '16h 05m',
                classes: ['1A', '2A', '3A'],
                availability: 'RAC',
                type: 'Superfast',
                days: ['Daily']
            },

            // Bangalore to Chennai trains
            {
                number: '12007',
                name: 'Shatabdi Express',
                from: 'Bangalore',
                to: 'Chennai Central',
                departureTime: '06:00',
                arrivalTime: '11:00',
                duration: '5h 00m',
                classes: ['CC', 'EC'],
                availability: 'Available',
                type: 'Express',
                days: ['Daily except Sunday']
            },
            {
                number: '12639',
                name: 'Brindavan Express',
                from: 'Bangalore',
                to: 'Chennai Central',
                departureTime: '07:00',
                arrivalTime: '12:30',
                duration: '5h 30m',
                classes: ['CC', 'SL', '2A'],
                availability: 'Available',
                type: 'Express',
                days: ['Daily']
            },
            {
                number: '12028',
                name: 'Shatabdi Express',
                from: 'Bangalore',
                to: 'Chennai Central',
                departureTime: '15:00',
                arrivalTime: '20:15',
                duration: '5h 15m',
                classes: ['CC', 'EC'],
                availability: 'Waiting List',
                type: 'Express',
                days: ['Daily except Sunday']
            },

            // Chennai to Bangalore trains
            {
                number: '12008',
                name: 'Shatabdi Express',
                from: 'Chennai Central',
                to: 'Bangalore',
                departureTime: '13:00',
                arrivalTime: '18:00',
                duration: '5h 00m',
                classes: ['CC', 'EC'],
                availability: 'Available',
                type: 'Express',
                days: ['Daily except Sunday']
            },
            {
                number: '12640',
                name: 'Brindavan Express',
                from: 'Chennai Central',
                to: 'Bangalore',
                departureTime: '14:30',
                arrivalTime: '20:00',
                duration: '5h 30m',
                classes: ['CC', 'SL', '2A'],
                availability: 'RAC',
                type: 'Express',
                days: ['Daily']
            },

            // Delhi to Kolkata trains
            {
                number: '12313',
                name: 'Sealdah Rajdhani Express',
                from: 'New Delhi',
                to: 'Kolkata',
                departureTime: '16:35',
                arrivalTime: '10:00',
                duration: '17h 25m',
                classes: ['1A', '2A', '3A'],
                availability: 'Available',
                type: 'Superfast',
                days: ['Daily']
            },
            {
                number: '12311',
                name: 'Howrah Rajdhani Express',
                from: 'New Delhi',
                to: 'Kolkata',
                departureTime: '16:55',
                arrivalTime: '10:10',
                duration: '17h 15m',
                classes: ['1A', '2A', '3A'],
                availability: 'Waiting List',
                type: 'Superfast',
                days: ['Daily']
            },

            // Mumbai to Pune trains
            {
                number: '12127',
                name: 'Intercity Express',
                from: 'Mumbai Central',
                to: 'Pune',
                departureTime: '07:10',
                arrivalTime: '10:25',
                duration: '3h 15m',
                classes: ['CC', 'SL'],
                availability: 'Available',
                type: 'Express',
                days: ['Daily']
            },
            {
                number: '11007',
                name: 'Deccan Express',
                from: 'Mumbai Central',
                to: 'Pune',
                departureTime: '17:10',
                arrivalTime: '20:40',
                duration: '3h 30m',
                classes: ['SL', '3A', '2A'],
                availability: 'Available',
                type: 'Express',
                days: ['Daily']
            },

            // Hyderabad to Bangalore trains
            {
                number: '12785',
                name: 'Kacheguda Express',
                from: 'Hyderabad',
                to: 'Bangalore',
                departureTime: '06:00',
                arrivalTime: '17:00',
                duration: '11h 00m',
                classes: ['SL', '3A', '2A'],
                availability: 'Available',
                type: 'Express',
                days: ['Daily']
            },
            {
                number: '12163',
                name: 'Dadar Express',
                from: 'Hyderabad',
                to: 'Bangalore',
                departureTime: '21:45',
                arrivalTime: '08:30',
                duration: '10h 45m',
                classes: ['SL', '3A', '2A', '1A'],
                availability: 'RAC',
                type: 'Superfast',
                days: ['Daily']
            },

            // Delhi to Jaipur trains
            {
                number: '12015',
                name: 'Ajmer Shatabdi Express',
                from: 'New Delhi',
                to: 'Jaipur',
                departureTime: '06:05',
                arrivalTime: '10:30',
                duration: '4h 25m',
                classes: ['CC', 'EC'],
                availability: 'Available',
                type: 'Express',
                days: ['Daily except Sunday']
            },
            {
                number: '12413',
                name: 'Poornima Express',
                from: 'New Delhi',
                to: 'Jaipur',
                departureTime: '23:30',
                arrivalTime: '05:00',
                duration: '5h 30m',
                classes: ['SL', '3A', '2A'],
                availability: 'Available',
                type: 'Express',
                days: ['Daily']
            }
        ];
    }

    async searchTrains(searchParams) {
        const { from, to, date, class: travelClass, timePreference } = searchParams;
        
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 1000));
        
        // Find matching trains
        let matchingTrains = this.trains.filter(train => {
            const fromMatch = this.isStationMatch(train.from, from);
            const toMatch = this.isStationMatch(train.to, to);
            return fromMatch && toMatch;
        });

        // Apply filters
        if (travelClass && travelClass !== 'any') {
            matchingTrains = matchingTrains.filter(train => 
                train.classes.some(cls => cls.toLowerCase().includes(travelClass.toLowerCase()))
            );
        }

        if (timePreference) {
            matchingTrains = this.filterByTime(matchingTrains, timePreference);
        }

        // Sort by departure time
        matchingTrains.sort((a, b) => {
            const timeA = this.convertTimeToMinutes(a.departureTime);
            const timeB = this.convertTimeToMinutes(b.departureTime);
            return timeA - timeB;
        });

        // Add some randomization to availability for realism
        matchingTrains = matchingTrains.map(train => ({
            ...train,
            availability: this.getRandomAvailability()
        }));

        return matchingTrains.slice(0, 10); // Limit results
    }

    isStationMatch(stationName, searchTerm) {
        const station = stationName.toLowerCase();
        const search = searchTerm.toLowerCase();
        
        return station.includes(search) || 
               search.includes(station) ||
               station.replace(/\s+/g, '').includes(search.replace(/\s+/g, '')) ||
               this.getStationAliases(station).some(alias => 
                   alias.includes(search) || search.includes(alias)
               );
    }

    getStationAliases(station) {
        const aliases = {
            'new delhi': ['delhi', 'ndls', 'newdelhi'],
            'mumbai central': ['mumbai', 'bombay', 'cstm', 'mumbaicst'],
            'chennai central': ['chennai', 'madras', 'mas'],
            'kolkata': ['calcutta', 'hwh', 'howrah'],
            'bangalore': ['bengaluru', 'sbc', 'bangaluru'],
            'hyderabad': ['secunderabad', 'sc'],
            'pune': ['poona'],
            'goa': ['madgaon', 'mao']
        };
        
        return aliases[station] || [];
    }

    filterByTime(trains, timePreference) {
        const time = timePreference.toLowerCase();
        
        return trains.filter(train => {
            const hour = parseInt(train.departureTime.split(':')[0]);
            
            switch (time) {
                case 'morning':
                case 'early':
                    return hour >= 5 && hour < 12;
                case 'afternoon':
                case 'day':
                    return hour >= 12 && hour < 17;
                case 'evening':
                    return hour >= 17 && hour < 21;
                case 'night':
                case 'late':
                    return hour >= 21 || hour < 5;
                default:
                    return true;
            }
        });
    }

    convertTimeToMinutes(time) {
        const [hours, minutes] = time.split(':').map(Number);
        return hours * 60 + minutes;
    }

    getRandomAvailability() {
        const availabilities = [
            'Available', 'Available', 'Available', // Higher probability
            'RAC', 'RAC',
            'Waiting List', 'Waiting List',
            'GNWL 15', 'PQWL 8', 'RLWL 5'
        ];
        
        return availabilities[Math.floor(Math.random() * availabilities.length)];
    }

    getStationSuggestions(query) {
        const suggestions = this.stations.filter(station =>
            station.toLowerCase().includes(query.toLowerCase())
        );
        
        return suggestions.sort((a, b) => {
            // Prioritize exact matches and shorter names
            if (a.toLowerCase().startsWith(query.toLowerCase()) && 
                !b.toLowerCase().startsWith(query.toLowerCase())) {
                return -1;
            }
            if (b.toLowerCase().startsWith(query.toLowerCase()) && 
                !a.toLowerCase().startsWith(query.toLowerCase())) {
                return 1;
            }
            return a.length - b.length;
        });
    }
}

module.exports = TrainSearchService;