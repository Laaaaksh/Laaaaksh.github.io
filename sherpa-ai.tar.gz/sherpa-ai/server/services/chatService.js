class ChatService {
    constructor() {
        this.responses = this.initializeResponses();
        this.conversationContext = new Map(); // Store conversation history per session
    }

    initializeResponses() {
        return {
            greetings: [
                "Hello! I'm Sherpa AI, your intelligent travel companion. How can I help you today? 😊",
                "Hi there! I'm here to help with your train travel needs and answer any questions. What's on your mind?",
                "Hey! Sherpa AI at your service. Whether it's trains, travel tips, or just a chat - I'm here for you! 🚂"
            ],
            
            thanks: [
                "You're welcome! Always happy to help! 😊",
                "My pleasure! Is there anything else I can assist you with?",
                "Glad I could help! Feel free to ask me anything else.",
                "Anytime! That's what I'm here for! 🙌"
            ],

            about: [
                "I'm Sherpa AI, your intelligent train booking assistant! 🚂 I can help you:",
                "• Find trains between any stations in India",
                "• Get train timings, availability, and fare information", 
                "• Answer questions about train travel",
                "• Provide general assistance and have friendly conversations",
                "",
                "I'm designed to make your train journey planning easier and more enjoyable! What would you like to know?"
            ],

            capabilities: [
                "Here's what I can do for you:",
                "",
                "🚂 **Train Services:**",
                "• Search trains between any Indian stations",
                "• Check train timings and availability",
                "• Find fastest/cheapest routes",
                "• Get information about different train classes",
                "",
                "💬 **General Chat:**",
                "• Answer questions about train travel",
                "• Provide travel tips and advice", 
                "• Have friendly conversations",
                "• Help with general inquiries",
                "",
                "Just ask me anything - whether it's about trains or just want to chat!"
            ],

            help: [
                "I'm here to help! Here are some ways you can interact with me:",
                "",
                "📍 **For Train Search:**",
                "• 'Find trains from Delhi to Mumbai'",
                "• 'Show morning trains to Chennai'",
                "• 'Fastest trains from Bangalore to Hyderabad'",
                "",
                "💬 **For General Chat:**",
                "• Ask about train travel tips",
                "• Questions about Indian Railways",
                "• General conversation - I'm a good listener!",
                "",
                "What would you like to know or talk about?"
            ],

            travel_tips: [
                "Here are some helpful train travel tips in India:",
                "",
                "🎫 **Booking Tips:**",
                "• Book tickets in advance, especially during peak seasons",
                "• Check multiple train options for flexible timings",
                "• Consider Tatkal booking for last-minute travel",
                "",
                "🧳 **Travel Preparation:**",
                "• Carry valid ID proof while traveling",
                "• Pack light snacks and water",
                "• Keep important documents in easy-to-reach places",
                "",
                "📱 **During Journey:**",
                "• Use apps like NTES for live train status",
                "• Keep your phone charged with portable charger",
                "• Be mindful of your belongings",
                "",
                "Need more specific advice about any aspect of train travel?"
            ],

            weather: [
                "I don't have real-time weather data, but I can suggest checking reliable weather apps before your train journey!",
                "",
                "For train travel weather tips:",
                "☀️ Summer: Carry water, light clothes, sunscreen",
                "🌧️ Monsoon: Pack raincoat, waterproof bags",
                "❄️ Winter: Warm clothes, especially for overnight journeys",
                "",
                "Would you like me to help you find trains for your journey?"
            ],

            fallback: [
                "That's interesting! While I specialize in train travel assistance, I'm always happy to chat.",
                "I may not have all the answers, but I'm here to help however I can!",
                "Hmm, I'm not sure about that specific topic, but feel free to ask me about trains or anything else!",
                "I'm still learning! Is there anything about train travel I can help you with?",
                "That's a great question! While my expertise is in train booking, I enjoy our conversation."
            ],

            goodbye: [
                "Safe travels! Feel free to come back anytime you need help with train bookings! 🚂",
                "Goodbye! Hope your journey goes smoothly. I'm here whenever you need assistance!",
                "Take care! Don't hesitate to ask if you need any train travel help in the future!",
                "Bye! Wishing you pleasant journeys ahead! 👋"
            ]
        };
    }

    async processGeneralChat(message, sessionId = 'default') {
        const normalizedMessage = message.toLowerCase().trim();
        
        // Store conversation context
        if (!this.conversationContext.has(sessionId)) {
            this.conversationContext.set(sessionId, []);
        }
        
        const context = this.conversationContext.get(sessionId);
        context.push({ role: 'user', message: message, timestamp: new Date() });
        
        // Keep only last 10 messages for context
        if (context.length > 10) {
            context.splice(0, context.length - 10);
        }

        let response = this.generateResponse(normalizedMessage, context);
        
        // Add personality and context awareness
        response = this.addPersonality(response, normalizedMessage, context);
        
        // Store AI response in context
        context.push({ role: 'assistant', message: response, timestamp: new Date() });
        
        return {
            message: response,
            isGeneral: true,
            timestamp: new Date().toISOString(),
            sessionId: sessionId
        };
    }

    generateResponse(normalizedMessage, context) {
        // Check for various patterns and respond accordingly
        
        // Greetings
        if (this.matchesPattern(normalizedMessage, ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening', 'namaste'])) {
            return this.getRandomResponse('greetings');
        }

        // Thanks
        if (this.matchesPattern(normalizedMessage, ['thank', 'thanks', 'dhanyawad', 'appreciate'])) {
            return this.getRandomResponse('thanks');
        }

        // About/Who are you
        if (this.matchesPattern(normalizedMessage, ['who are you', 'what are you', 'about you', 'introduce yourself'])) {
            return this.responses.about.join('\n');
        }

        // Capabilities
        if (this.matchesPattern(normalizedMessage, ['what can you do', 'capabilities', 'features', 'help me'])) {
            return this.responses.capabilities.join('\n');
        }

        // Help
        if (this.matchesPattern(normalizedMessage, ['help', 'how to use', 'commands', 'options'])) {
            return this.responses.help.join('\n');
        }

        // Travel tips
        if (this.matchesPattern(normalizedMessage, ['travel tips', 'travel advice', 'train tips', 'journey tips', 'travel guide'])) {
            return this.responses.travel_tips.join('\n');
        }

        // Weather
        if (this.matchesPattern(normalizedMessage, ['weather', 'temperature', 'climate', 'season'])) {
            return this.responses.weather.join('\n');
        }

        // Goodbye
        if (this.matchesPattern(normalizedMessage, ['bye', 'goodbye', 'see you', 'take care', 'exit', 'quit'])) {
            return this.getRandomResponse('goodbye');
        }

        // Train-related but not search
        if (this.matchesPattern(normalizedMessage, ['railway', 'irctc', 'indian railways', 'train system', 'rail network'])) {
            return "Indian Railways is one of the world's largest rail networks! 🚂\n\nSome interesting facts:\n• Connects over 7,000 stations\n• Runs 20,000+ trains daily\n• Employs over 1.3 million people\n• Covers 67,000+ km of track\n\nWould you like me to help you find specific trains for your journey?";
        }

        // Food questions
        if (this.matchesPattern(normalizedMessage, ['food', 'meal', 'dining', 'pantry', 'snacks'])) {
            return "🍽️ Train food options in India:\n\n• **Pantry Car**: Many long-distance trains have dining cars\n• **Station Food**: Fresh meals at major stations\n• **Mobile Vendors**: Snacks and beverages during stops\n• **Pre-order**: Book meals through IRCTC for delivery at your seat\n\n**Pro tip**: Carry some snacks and water, especially for long journeys!\n\nNeed help finding trains with good food services?";
        }

        // Time/Schedule questions
        if (this.matchesPattern(normalizedMessage, ['time', 'schedule', 'timing', 'punctuality', 'delay'])) {
            return "⏰ About train timings:\n\n• Most trains run on schedule, but delays can happen\n• Check live status on NTES app or IRCTC website\n• Rajdhani and Shatabdi trains are generally more punctual\n• Weather and track maintenance can cause delays\n\n**Tip**: Always reach station 30 minutes before departure!\n\nWant me to find specific train timings for your route?";
        }

        // Personal questions
        if (this.matchesPattern(normalizedMessage, ['how are you', 'how do you feel', 'are you okay', 'whats up'])) {
            return "I'm doing great, thank you for asking! 😊 I'm always excited to help people with their travel plans. There's something wonderful about connecting people to their destinations.\n\nHow are you doing? Planning a trip somewhere?";
        }

        // Compliments
        if (this.matchesPattern(normalizedMessage, ['good job', 'well done', 'amazing', 'awesome', 'great', 'excellent', 'wonderful'])) {
            return "Aww, thank you so much! 🙏 That really means a lot to me. I try my best to be helpful and make your travel planning easier.\n\nIs there anything else I can assist you with today?";
        }

        // Default fallback with personality
        return this.getContextualFallback(normalizedMessage, context);
    }

    matchesPattern(message, patterns) {
        return patterns.some(pattern => message.includes(pattern));
    }

    getRandomResponse(category) {
        const responses = this.responses[category];
        return responses[Math.floor(Math.random() * responses.length)];
    }

    addPersonality(response, message, context) {
        // Add personality based on conversation context
        const recentMessages = context.slice(-5);
        const isRepeatUser = recentMessages.length > 2;
        
        if (isRepeatUser && Math.random() > 0.7) {
            const personalityTouches = [
                "By the way, I love how curious you are! ",
                "I really enjoy our chat! ",
                "You know, you ask great questions! ",
                "I appreciate your interest! "
            ];
            
            const touch = personalityTouches[Math.floor(Math.random() * personalityTouches.length)];
            return touch + response;
        }
        
        return response;
    }

    getContextualFallback(message, context) {
        const fallbackResponses = [
            `That's an interesting question about "${message}"! While I'm primarily designed to help with train travel, I enjoy our conversation.`,
            
            `I appreciate you sharing that with me! Though my specialty is train booking, I'm always happy to chat.`,
            
            `"${message}" - that's something I'd love to learn more about! For now, I'm most knowledgeable about Indian train travel.`,
            
            `Thanks for that question! While I might not have all the answers about "${message}", I'm here to help with whatever I can.`,
            
            `That's a thoughtful question! I may not be an expert on everything, but I'd love to help you plan any train journeys.`
        ];

        const baseResponse = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
        
        const suggestions = [
            "\n\nIs there anything about train travel I can help you with?",
            "\n\nWould you like me to help you search for any trains?",
            "\n\nAny train journey you're planning that I could assist with?",
            "\n\nFeel free to ask me about trains between any Indian cities!"
        ];
        
        const suggestion = suggestions[Math.floor(Math.random() * suggestions.length)];
        
        return baseResponse + suggestion;
    }

    // Method to determine if a message is train-related
    isTrainQuery(message) {
        const trainKeywords = [
            'train', 'trains', 'from', 'to', 'find', 'search', 'book', 'ticket',
            'station', 'railway', 'express', 'local', 'rajdhani', 'shatabdi',
            'departure', 'arrival', 'journey', 'travel', 'route', 'schedule',
            'timing', 'fare', 'price', 'available', 'seat', 'berth', 'class',
            'ac', 'sleeper', 'morning', 'evening', 'night', 'fast', 'direct'
        ];

        const normalizedMessage = message.toLowerCase();
        
        // Check for station patterns (city to city)
        const hasFromTo = /from\s+\w+\s+to\s+\w+|between\s+\w+\s+and\s+\w+|\w+\s+to\s+\w+/.test(normalizedMessage);
        
        // Check for train keywords
        const hasTrainKeywords = trainKeywords.some(keyword => 
            normalizedMessage.includes(keyword)
        );

        // Check for major city names
        const majorCities = [
            'delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'hyderabad',
            'pune', 'ahmedabad', 'jaipur', 'lucknow', 'kanpur', 'nagpur',
            'goa', 'kochi', 'trivandrum', 'amritsar', 'jammu', 'varanasi'
        ];
        
        const hasCityNames = majorCities.filter(city => 
            normalizedMessage.includes(city)
        ).length >= 2;

        return hasFromTo || (hasTrainKeywords && normalizedMessage.length > 10) || hasCityNames;
    }
}

module.exports = ChatService;