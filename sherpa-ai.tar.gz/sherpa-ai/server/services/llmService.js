// LLM Service for Sherpa AI
const Groq = require('groq-sdk');

class LLMService {
    constructor() {
        this.groq = process.env.GROQ_API_KEY ? new Groq({
            apiKey: process.env.GROQ_API_KEY
        }) : null;
        
        this.systemPrompt = \`You are Sherpa AI, an intelligent and friendly train booking assistant for India. You have a warm, helpful personality and can assist with:

1. TRAIN-RELATED QUERIES: For any train search, booking, or railway-related questions, you provide helpful information about Indian Railways, travel tips, and guidance.

2. GENERAL CONVERSATION: For non-train topics, you engage in natural, friendly conversation while maintaining your identity as a travel assistant.

Your personality traits:
- Warm, friendly, and approachable
- Knowledgeable about Indian train travel
- Helpful and solution-oriented
- Conversational and engaging
- Professional but not formal

Always maintain context of being a train booking assistant, but feel free to chat about other topics naturally. If users ask about train searches specifically, guide them to use proper station names and provide helpful travel advice.

Keep responses concise but helpful, typically 1-3 paragraphs. Use emojis sparingly but appropriately.\`;
    }

    async generateResponse(message, conversationHistory = []) {
        if (!this.groq) {
            throw new Error('LLM service not configured - GROQ_API_KEY not provided');
        }

        try {
            const messages = [
                { role: 'system', content: this.systemPrompt }
            ];

            const recentHistory = conversationHistory.slice(-6);
            recentHistory.forEach(msg => {
                if (msg.role === 'user' || msg.role === 'assistant') {
                    messages.push({
                        role: msg.role,
                        content: msg.message || msg.content
                    });
                }
            });

            messages.push({ role: 'user', content: message });

            const chatCompletion = await this.groq.chat.completions.create({
                messages: messages,
                model: 'llama-3.1-8b-instant',
                temperature: 0.7,
                max_tokens: 500,
                top_p: 0.9
            });

            const response = chatCompletion.choices[0]?.message?.content?.trim();
            
            if (!response) {
                throw new Error('Empty response from LLM');
            }

            return response;

        } catch (error) {
            console.error('Error generating LLM response:', error);
            throw error;
        }
    }

    isConfigured() {
        return !!this.groq;
    }

    getStatus() {
        return {
            isConfigured: this.isConfigured(),
            apiKeyPresent: !!process.env.GROQ_API_KEY,
            model: 'llama-3.1-8b-instant'
        };
    }
}

module.exports = LLMService;
