class QueryProcessor {
    constructor() {
        this.stationPatterns = this.initializeStationPatterns();
        this.timePatterns = this.initializeTimePatterns();
        this.classPatterns = this.initializeClassPatterns();
    }

    initializeStationPatterns() {
        return [
            // Common station mappings
            { pattern: /delhi|new delhi|ndls/i, station: 'New Delhi' },
            { pattern: /mumbai|bombay|mumbai central|cstm/i, station: 'Mumbai Central' },
            { pattern: /chennai|madras|chennai central|mas/i, station: 'Chennai Central' },
            { pattern: /kolkata|calcutta|howrah|hwh/i, station: 'Kolkata' },
            { pattern: /bangalore|bengaluru|sbc/i, station: 'Bangalore' },
            { pattern: /hyderabad|secunderabad|sc/i, station: 'Hyderabad' },
            { pattern: /pune|poona/i, station: 'Pune' },
            { pattern: /ahmedabad|adi/i, station: 'Ahmedabad' },
            { pattern: /jaipur|jp/i, station: 'Jaipur' },
            { pattern: /lucknow|lko/i, station: 'Lucknow' },
            { pattern: /kanpur|cnb/i, station: 'Kanpur' },
            { pattern: /nagpur|ngp/i, station: 'Nagpur' },
            { pattern: /indore|indb/i, station: 'Indore' },
            { pattern: /bhopal|bpl/i, station: 'Bhopal' },
            { pattern: /chandigarh|cdg/i, station: 'Chandigarh' },
            { pattern: /coimbatore|cbe/i, station: 'Coimbatore' },
            { pattern: /kochi|cochin|ers/i, station: 'Kochi' },
            { pattern: /thiruvananthapuram|trivandrum|tvc/i, station: 'Thiruvananthapuram' },
            { pattern: /goa|madgaon|mao/i, station: 'Goa' },
            { pattern: /varanasi|banaras|bsb/i, station: 'Varanasi' },
            { pattern: /agra|agc/i, station: 'Agra' },
            { pattern: /amritsar|asr/i, station: 'Amritsar' },
            { pattern: /jammu|jat/i, station: 'Jammu' }
        ];
    }

    initializeTimePatterns() {
        return [
            { pattern: /morning|early morning|dawn|6am|7am|8am|9am|10am|11am/i, time: 'morning' },
            { pattern: /afternoon|noon|12pm|1pm|2pm|3pm|4pm|day time/i, time: 'afternoon' },
            { pattern: /evening|5pm|6pm|7pm|8pm/i, time: 'evening' },
            { pattern: /night|late night|9pm|10pm|11pm|12am|1am|2am|3am|4am|5am/i, time: 'night' }
        ];
    }

    initializeClassPatterns() {
        return [
            { pattern: /first class|1a|first ac|ac first/i, class: '1A' },
            { pattern: /second ac|2a|ac 2|2-tier/i, class: '2A' },
            { pattern: /third ac|3a|ac 3|3-tier/i, class: '3A' },
            { pattern: /sleeper|sl|non-ac|non ac/i, class: 'SL' },
            { pattern: /chair car|cc|seater/i, class: 'CC' },
            { pattern: /executive|ec|executive chair/i, class: 'EC' },
            { pattern: /general|unreserved/i, class: 'GEN' }
        ];
    }

    parseQuery(query) {
        const result = {
            from: null,
            to: null,
            date: null,
            class: null,
            timePreference: null,
            trainType: null,
            originalQuery: query
        };

        // Extract stations using common patterns
        const stations = this.extractStations(query);
        if (stations.length >= 2) {
            result.from = stations[0];
            result.to = stations[1];
        } else if (stations.length === 1) {
            // Try to infer from context
            const fromToMatch = this.extractFromToPattern(query);
            if (fromToMatch.from && fromToMatch.to) {
                result.from = fromToMatch.from;
                result.to = fromToMatch.to;
            }
        }

        // If still no stations found, try pattern matching
        if (!result.from || !result.to) {
            const patternMatch = this.extractFromToPattern(query);
            if (patternMatch.from) result.from = patternMatch.from;
            if (patternMatch.to) result.to = patternMatch.to;
        }

        // Extract time preference
        result.timePreference = this.extractTimePreference(query);

        // Extract class preference
        result.class = this.extractClass(query);

        // Extract train type
        result.trainType = this.extractTrainType(query);

        // Extract date (simple patterns)
        result.date = this.extractDate(query);

        return result;
    }

    extractStations(query) {
        const stations = [];
        
        // Try to match against known station patterns
        for (const pattern of this.stationPatterns) {
            if (pattern.pattern.test(query)) {
                stations.push(pattern.station);
            }
        }

        // Remove duplicates
        return [...new Set(stations)];
    }

    extractFromToPattern(query) {
        const result = { from: null, to: null };
        
        // Common patterns for from-to queries
        const patterns = [
            // "from X to Y" pattern
            /from\s+([a-zA-Z\s]+?)\s+to\s+([a-zA-Z\s]+)/i,
            // "X to Y" pattern
            /([a-zA-Z\s]+?)\s+to\s+([a-zA-Z\s]+)/i,
            // "X - Y" pattern
            /([a-zA-Z\s]+?)\s*[-–—]\s*([a-zA-Z\s]+)/i,
            // "between X and Y" pattern
            /between\s+([a-zA-Z\s]+?)\s+and\s+([a-zA-Z\s]+)/i
        ];

        for (const pattern of patterns) {
            const match = query.match(pattern);
            if (match) {
                const from = this.normalizeStationName(match[1].trim());
                const to = this.normalizeStationName(match[2].trim());
                
                if (from && to) {
                    result.from = from;
                    result.to = to;
                    break;
                }
            }
        }

        return result;
    }

    normalizeStationName(stationName) {
        const normalized = stationName.toLowerCase().trim();
        
        // Find matching station pattern
        for (const pattern of this.stationPatterns) {
            if (pattern.pattern.test(normalized)) {
                return pattern.station;
            }
        }

        // If no pattern matches, try to capitalize properly
        return stationName.split(' ')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
            .join(' ');
    }

    extractTimePreference(query) {
        for (const pattern of this.timePatterns) {
            if (pattern.pattern.test(query)) {
                return pattern.time;
            }
        }
        return null;
    }

    extractClass(query) {
        for (const pattern of this.classPatterns) {
            if (pattern.pattern.test(query)) {
                return pattern.class;
            }
        }
        return null;
    }

    extractTrainType(query) {
        const types = [
            { pattern: /rajdhani/i, type: 'Rajdhani' },
            { pattern: /shatabdi/i, type: 'Shatabdi' },
            { pattern: /express/i, type: 'Express' },
            { pattern: /superfast|super fast/i, type: 'Superfast' },
            { pattern: /local|passenger/i, type: 'Local' },
            { pattern: /duronto/i, type: 'Duronto' },
            { pattern: /garib rath|garibrath/i, type: 'Garib Rath' },
            { pattern: /jan shatabdi|janshatabdi/i, type: 'Jan Shatabdi' },
            { pattern: /fastest|fast/i, type: 'fastest' }
        ];

        for (const type of types) {
            if (type.pattern.test(query)) {
                return type.type;
            }
        }
        
        return null;
    }

    extractDate(query) {
        const datePatterns = [
            { pattern: /today/i, date: 'today' },
            { pattern: /tomorrow/i, date: 'tomorrow' },
            { pattern: /day after tomorrow|day after/i, date: 'day_after_tomorrow' },
            { pattern: /(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/i, date: 'specific' },
            { pattern: /(monday|tuesday|wednesday|thursday|friday|saturday|sunday)/i, date: 'day_of_week' }
        ];

        for (const pattern of datePatterns) {
            const match = query.match(pattern.pattern);
            if (match) {
                if (pattern.date === 'specific') {
                    return `${match[1]}/${match[2]}/${match[3]}`;
                } else if (pattern.date === 'day_of_week') {
                    return match[1].toLowerCase();
                } else {
                    return pattern.date;
                }
            }
        }

        return null;
    }

    // Utility method to get suggestions for incomplete queries
    getSuggestions(partialQuery) {
        const suggestions = [];
        
        // If query is too short, provide generic suggestions
        if (partialQuery.length < 3) {
            return [
                'Find trains from Delhi to Mumbai',
                'Show trains from Bangalore to Chennai',
                'Mumbai to Pune trains',
                'Morning trains from Delhi'
            ];
        }

        // Try to detect what user is typing and suggest completions
        const query = partialQuery.toLowerCase();
        
        if (query.includes('from') && !query.includes('to')) {
            suggestions.push(
                `${partialQuery} to Mumbai`,
                `${partialQuery} to Delhi`,
                `${partialQuery} to Bangalore`,
                `${partialQuery} to Chennai`
            );
        }
        
        if (query.includes('trains') && !query.includes('from') && !query.includes('to')) {
            suggestions.push(
                `Find trains from ${partialQuery.replace('trains', '').trim()} to`,
                `${partialQuery} from Delhi`,
                `${partialQuery} from Mumbai`
            );
        }

        return suggestions.slice(0, 4);
    }
}

module.exports = QueryProcessor;