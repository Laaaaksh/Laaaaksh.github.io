// Sherpa AI - Frontend JavaScript

class SherpaAI {
    constructor() {
        this.apiEndpoint = '/api/search-trains';
        this.messageInput = document.getElementById('messageInput');
        this.sendButton = document.getElementById('sendButton');
        this.chatMessages = document.getElementById('chatMessages');
        this.loadingIndicator = document.getElementById('loadingIndicator');
        this.inputSuggestions = document.getElementById('inputSuggestions');
        
        this.initializeEventListeners();
        this.showWelcomeTime();
        this.showSuggestions();
    }

    initializeEventListeners() {
        // Send message on button click
        this.sendButton.addEventListener('click', () => this.sendMessage());
        
        // Send message on Enter key press
        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        // Auto-resize input and show suggestions
        this.messageInput.addEventListener('input', () => {
            this.updateSendButton();
            this.showSuggestions();
        });

        // Initial button state
        this.updateSendButton();
    }

    showWelcomeTime() {
        const welcomeTime = document.getElementById('welcomeTime');
        if (welcomeTime) {
            welcomeTime.textContent = new Date().toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit'
            });
        }
    }

    updateSendButton() {
        const hasText = this.messageInput.value.trim().length > 0;
        this.sendButton.disabled = !hasText;
    }

    showSuggestions() {
        const input = this.messageInput.value.toLowerCase();
        const suggestions = this.getSuggestions(input);
        
        this.inputSuggestions.innerHTML = '';
        suggestions.forEach(suggestion => {
            const chip = document.createElement('div');
            chip.className = 'suggestion-chip';
            chip.textContent = suggestion;
            chip.onclick = () => {
                this.messageInput.value = suggestion;
                this.messageInput.focus();
                this.updateSendButton();
                this.inputSuggestions.innerHTML = '';
            };
            this.inputSuggestions.appendChild(chip);
        });
    }

    getSuggestions(input) {
        const allSuggestions = [
            'Find trains from Delhi to Mumbai',
            'Show trains from Bangalore to Chennai',
            'Mumbai to Delhi express trains',
            'Kolkata to Pune fastest trains',
            'Morning trains from Hyderabad to Delhi',
            'Chennai to Bangalore superfast trains',
            'Delhi to Kolkata Rajdhani trains',
            'Mumbai to Pune local trains',
            'Express trains from Jaipur to Delhi',
            'Overnight trains from Delhi to Bangalore'
        ];

        if (!input || input.length < 2) {
            return allSuggestions.slice(0, 3);
        }

        return allSuggestions.filter(suggestion => 
            suggestion.toLowerCase().includes(input)
        ).slice(0, 4);
    }

    async sendMessage(message = null) {
        const text = message || this.messageInput.value.trim();
        if (!text) return;

        // Add user message to chat
        this.addMessage(text, 'user');
        
        // Clear input
        if (!message) {
            this.messageInput.value = '';
            this.updateSendButton();
            this.inputSuggestions.innerHTML = '';
        }

        // Show loading indicator
        this.showLoading(true);

        try {
            // Send request to backend
            const response = await fetch(this.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query: text })
            });

            const data = await response.json();

            if (response.ok) {
                this.handleSearchResponse(data);
            } else {
                this.addMessage(
                    `❌ Sorry, I encountered an error: ${data.error || 'Unknown error'}`,
                    'bot'
                );
            }
        } catch (error) {
            console.error('Error:', error);
            this.addMessage(
                '❌ Sorry, I\'m having trouble connecting to the server. Please try again later.',
                'bot'
            );
        } finally {
            this.showLoading(false);
        }
    }

    handleSearchResponse(data) {
        if (data.trains && data.trains.length > 0) {
            let response = `🚂 I found ${data.trains.length} trains for your search:\n\n`;
            
            data.trains.forEach((train, index) => {
                response += this.formatTrainResult(train, index + 1);
            });

            this.addMessage(response, 'bot', data.trains);
        } else if (data.message) {
            this.addMessage(data.message, 'bot');
        } else {
            this.addMessage(
                '😔 I couldn\'t find any trains for your search. Please try with different stations or check your spelling.',
                'bot'
            );
        }
    }

    formatTrainResult(train, index) {
        return `**${index}. ${train.name} (${train.number})**\n` +
               `🚉 ${train.from} → ${train.to}\n` +
               `⏰ Departure: ${train.departureTime} | Arrival: ${train.arrivalTime}\n` +
               `⏱️ Duration: ${train.duration}\n` +
               `💺 Classes: ${train.classes.join(', ')}\n` +
               `📊 Availability: ${train.availability}\n\n`;
    }

    addMessage(text, sender, trainsData = null) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;

        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'message-avatar';
        avatarDiv.innerHTML = sender === 'user' ? 
            '<i class="fas fa-user"></i>' : 
            '<i class="fas fa-robot"></i>';

        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';

        const textDiv = document.createElement('div');
        textDiv.className = 'message-text';

        if (trainsData) {
            // Create formatted train results
            textDiv.innerHTML = this.createTrainResultsHTML(trainsData);
        } else {
            // Format regular text with markdown-like styling
            textDiv.innerHTML = this.formatMessageText(text);
        }

        const timeDiv = document.createElement('div');
        timeDiv.className = 'message-time';
        timeDiv.textContent = new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
        });

        contentDiv.appendChild(textDiv);
        contentDiv.appendChild(timeDiv);
        messageDiv.appendChild(avatarDiv);
        messageDiv.appendChild(contentDiv);

        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
    }

    createTrainResultsHTML(trains) {
        let html = `<div style="margin-bottom: 1rem;">
            <strong>🚂 Found ${trains.length} trains for your journey:</strong>
        </div>`;

        trains.forEach((train, index) => {
            html += `
                <div class="train-result">
                    <div class="train-header">
                        <div class="train-name">${train.name}</div>
                        <div class="train-number">${train.number}</div>
                    </div>
                    <div class="train-details">
                        <div class="detail-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${train.from} → ${train.to}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-clock"></i>
                            <span>${train.departureTime} - ${train.arrivalTime}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-hourglass-half"></i>
                            <span>${train.duration}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-chair"></i>
                            <span>${train.classes.join(', ')}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-info-circle"></i>
                            <span>${train.availability}</span>
                        </div>
                    </div>
                </div>
            `;
        });

        return html;
    }

    formatMessageText(text) {
        return text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n/g, '<br>')
            .replace(/(\d+\.\s)/g, '<br>$1');
    }

    scrollToBottom() {
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }

    showLoading(show) {
        if (show) {
            this.loadingIndicator.classList.add('show');
            this.sendButton.disabled = true;
        } else {
            this.loadingIndicator.classList.remove('show');
            this.updateSendButton();
        }
    }

    clearChat() {
        // Keep only the welcome message
        const messages = this.chatMessages.querySelectorAll('.message');
        for (let i = 1; i < messages.length; i++) {
            messages[i].remove();
        }
    }
}

// Utility Functions
function sendQuickMessage(message) {
    if (window.sherpaAI) {
        window.sherpaAI.sendMessage(message);
    }
}

function showAbout() {
    const modal = document.getElementById('aboutModal');
    modal.classList.add('show');
}

function showHelp() {
    const modal = document.getElementById('helpModal');
    modal.classList.add('show');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
}

function clearChat() {
    if (window.sherpaAI) {
        const confirmClear = confirm('Are you sure you want to clear the chat history?');
        if (confirmClear) {
            window.sherpaAI.clearChat();
        }
    }
}

// Close modals when clicking outside
document.addEventListener('click', (e) => {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (e.target === modal) {
            modal.classList.remove('show');
        }
    });
});

// Handle escape key to close modals
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        const modals = document.querySelectorAll('.modal.show');
        modals.forEach(modal => {
            modal.classList.remove('show');
        });
    }
});

// Error handling for API requests
window.addEventListener('online', () => {
    console.log('Connection restored');
});

window.addEventListener('offline', () => {
    console.log('Connection lost');
    if (window.sherpaAI) {
        window.sherpaAI.addMessage(
            '⚠️ You appear to be offline. Please check your internet connection.',
            'bot'
        );
    }
});

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚂 Sherpa AI initializing...');
    window.sherpaAI = new SherpaAI();
    console.log('✅ Sherpa AI ready!');
});

// Service Worker for PWA capabilities (optional enhancement)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}