# 🚂 Sherpa AI - Your Intelligent Train Booking Assistant

<div align="center">

![Sherpa AI Logo](https://img.shields.io/badge/🚂_Sherpa_AI-Train_Booking_Assistant-blue?style=for-the-badge)

**Your intelligent companion for train travel across India**

[![Node.js](https://img.shields.io/badge/Node.js-18.x+-green?style=flat-square&logo=node.js)](https://nodejs.org/)
[![Express](https://img.shields.io/badge/Express-4.x-lightgrey?style=flat-square&logo=express)](https://expressjs.com/)
[![JavaScript](https://img.shields.io/badge/JavaScript-ES6+-yellow?style=flat-square&logo=javascript)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![CSS3](https://img.shields.io/badge/CSS3-Modern-blue?style=flat-square&logo=css3)](https://www.w3.org/Style/CSS/)

</div>

---

## 🌟 About Sherpa AI

Sherpa AI is an intelligent chatbot designed to help you find and explore train routes across India. Whether you're planning a quick weekend getaway or a cross-country journey, Sherpa AI makes train travel planning conversational, intuitive, and fun!

### ✨ Key Features

🤖 **Intelligent Conversation**
- Natural language processing for train queries
- General chat capabilities - talk about anything!
- Context-aware responses that remember your conversation

🔍 **Smart Train Search**
- Find trains between any Indian stations
- Support for flexible queries like "morning trains to Mumbai"
- Real-time-like availability and timing information

💬 **Conversational Interface**
- Beautiful, modern chat UI
- Quick action buttons for common routes
- Mobile-responsive design

🚀 **Advanced Features**
- Auto-suggestions as you type
- Station code recognition (NDLS, CSTM, etc.)
- Travel tips and advice
- Comprehensive help system

---

## 🚀 Quick Start

### Prerequisites

- **Node.js** 16.x or higher
- **npm** or **yarn**

### Installation

1. **Clone and navigate to the project**
   ```bash
   git clone <your-repo-url>
   cd sherpa-ai
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the application**
   ```bash
   npm start
   ```

4. **Open your browser**
   ```
   http://localhost:3000
   ```

That's it! 🎉 Sherpa AI is now running locally.

---

## 💬 How to Use Sherpa AI

### 🚂 For Train Search

Ask Sherpa AI about trains using natural language:

```
"Find trains from Delhi to Mumbai"
"Show morning trains from Bangalore to Chennai"  
"What are the fastest trains to Pune?"
"Mumbai to Goa trains tomorrow"
"Express trains from Kolkata to Delhi"
```

### 💭 For General Chat

Sherpa AI loves to chat! Try asking:

```
"Hello Sherpa!"
"Who are you?"
"Tell me about Indian Railways"
"Any travel tips?"
"How are you today?"
```

### 🎯 Quick Actions

Use the quick action buttons for popular routes:
- Delhi ↔ Mumbai
- Bangalore ↔ Chennai  
- Mumbai ↔ Pune

---

## 🛠 Technical Architecture

### Frontend
- **HTML5** with semantic structure
- **CSS3** with modern flexbox/grid layouts
- **Vanilla JavaScript** with ES6+ features
- **Progressive Web App** capabilities

### Backend
- **Node.js** with Express.js framework
- **RESTful API** design
- **Modular service architecture**
- **Error handling** and logging

### Services Architecture

```
📁 server/
├── 📄 index.js              # Main server & routing
└── 📁 services/
    ├── 📄 trainSearchService.js    # Train data & search logic
    ├── 📄 queryProcessor.js        # NLP query parsing
    └── 📄 chatService.js           # General conversation AI
```

---

## 🔧 API Endpoints

### Main Chat Endpoint
```http
POST /api/search-trains
Content-Type: application/json

{
  "query": "Find trains from Delhi to Mumbai",
  "sessionId": "optional-session-id"
}
```

**Response for Train Search:**
```json
{
  "trains": [...],
  "message": "Found 5 trains from Delhi to Mumbai",
  "isTrainSearch": true,
  "timestamp": "2024-01-01T10:00:00.000Z"
}
```

**Response for General Chat:**
```json
{
  "message": "Hello! I'm Sherpa AI...",
  "isGeneral": true,
  "isTrainSearch": false,
  "timestamp": "2024-01-01T10:00:00.000Z"
}
```

### Other Endpoints
- `GET /api/health` - Health check
- `GET /api/stations/suggest/:query` - Station suggestions
- `GET /api/popular-routes` - Popular train routes

---

## 🎨 Features Deep Dive

### 🧠 Natural Language Processing

Sherpa AI understands various ways to express train search queries:

- **Flexible station names**: "Delhi", "New Delhi", "NDLS" all work
- **Time preferences**: "morning", "evening", "night" trains
- **Train types**: "express", "superfast", "Rajdhani" trains
- **Date expressions**: "today", "tomorrow", "next Monday"

### 💬 Conversational AI

The general chat system provides:

- **Contextual responses** based on conversation history
- **Travel tips** and advice for train journeys
- **Information** about Indian Railways
- **Personality** that makes conversations engaging

### 🔍 Smart Search Features

- **Fuzzy matching** for station names
- **Multiple result formats** with rich train information
- **Availability simulation** with realistic status updates
- **Sorting and filtering** options

---

## 🛠 Development

### Project Structure

```
sherpa-ai/
├── 📄 index.html           # Main HTML file
├── 📄 styles.css           # CSS styling
├── 📄 script.js            # Frontend JavaScript
├── 📄 package.json         # Node.js dependencies
├── 📄 README.md            # Documentation
├── 📄 .gitignore           # Git ignore rules
└── 📁 server/
    ├── 📄 index.js         # Express server
    └── 📁 services/        # Backend services
```

### Development Scripts

```bash
# Start development server
npm run dev

# Start production server  
npm start

# Install dependencies
npm install
```

### Environment Variables

Create a `.env` file for configuration:

```env
PORT=3000
NODE_ENV=development
SESSION_SECRET=your-secret-key
```

---

## 🚀 Deployment

### Local Deployment
```bash
npm start
```

### Production Deployment

**Using PM2:**
```bash
npm install -g pm2
pm2 start server/index.js --name sherpa-ai
```

**Using Docker:**
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

**Deploy to Cloud:**
- **Heroku**: Push to Heroku with `Procfile`
- **Railway**: Connect GitHub repo
- **DigitalOcean**: Use App Platform
- **AWS**: Use Elastic Beanstalk

---

## 🤝 Contributing

We welcome contributions! Here's how you can help:

### 🐛 Bug Reports
- Use GitHub Issues
- Include steps to reproduce
- Provide browser/OS information

### ✨ Feature Requests  
- Describe the feature clearly
- Explain the use case
- Check existing issues first

### 🔧 Pull Requests
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

### 📝 Development Guidelines
- Follow existing code style
- Add comments for complex logic
- Update documentation as needed
- Test thoroughly before submitting

---

## 🛡 Technical Considerations

### 🔒 Security
- Input validation and sanitization
- CORS protection
- Helmet.js security headers
- Session management (planned)

### ⚡ Performance
- Async/await for non-blocking operations
- Efficient search algorithms
- Frontend caching strategies
- Optimized CSS and JavaScript

### 📱 Accessibility
- Semantic HTML structure
- ARIA labels for screen readers
- Keyboard navigation support
- High contrast color scheme

---

## 🗺 Roadmap

### 🎯 Near Term (v1.1)
- [ ] Real IRCTC API integration
- [ ] User authentication system
- [ ] Booking capability
- [ ] Push notifications

### 🚀 Medium Term (v1.5)
- [ ] Mobile app (React Native)
- [ ] Offline capabilities
- [ ] Multi-language support
- [ ] Voice commands

### 🌟 Long Term (v2.0)
- [ ] AI-powered journey planning
- [ ] Hotel and cab integration
- [ ] Social features
- [ ] Analytics dashboard

---

## 📞 Support & Contact

### 🆘 Getting Help
- **Documentation**: Check this README first
- **Issues**: Use GitHub Issues for bugs
- **Discussions**: GitHub Discussions for questions

### 📧 Contact
- **Email**: [your-email@example.com]
- **Twitter**: [@YourHandle]
- **LinkedIn**: [Your Profile]

---

## 📄 License

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

```
MIT License

Copyright (c) 2024 Sherpa AI

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software...
```

---

## 🙏 Acknowledgments

- **Indian Railways** for the inspiration
- **Express.js** community for the excellent framework
- **Node.js** team for the powerful runtime
- **Contributors** who make this project better

---

<div align="center">

**🚂 Built with ❤️ for Indian train travelers**

[![GitHub Stars](https://img.shields.io/github/stars/your-username/sherpa-ai?style=social)](https://github.com/your-username/sherpa-ai)
[![Follow on Twitter](https://img.shields.io/twitter/follow/YourHandle?style=social)](https://twitter.com/YourHandle)

**[⬆ Back to Top](#-sherpa-ai---your-intelligent-train-booking-assistant)**

</div>